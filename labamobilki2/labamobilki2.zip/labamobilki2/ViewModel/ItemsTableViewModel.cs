﻿using labamobilki2.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Text;

namespace labamobilki2.ViewModel
{
    public class ItemsTableViewModel : INotifyPropertyChanged
    {
        public List<ItemCellViewModel> viewModels;

        public ItemsTableViewModel(Items repository)
        {
            foreach (var item in repository.items)
            {
                viewModels.Add(new ItemCellViewModel(item));
            }
        }
        
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
