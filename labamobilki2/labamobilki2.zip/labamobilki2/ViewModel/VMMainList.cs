﻿using System;
using System.Collections.Generic;
using System.Text;

namespace labamobilki2.ViewModel
{
    public class VMMainList
    {
        public List<VMMain> Elements { get; set; }
    }
}
