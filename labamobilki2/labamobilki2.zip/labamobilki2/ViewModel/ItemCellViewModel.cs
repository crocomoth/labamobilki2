﻿using labamobilki2.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace labamobilki2.ViewModel
{
    public class ItemCellViewModel : INotifyPropertyChanged
    {
        public Item Item { get; private set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public ItemCellViewModel()
        {
            Item = new Item();
        }

        public ItemCellViewModel(Item item)
        {
            Item = item;
        }

        public String Image
        {
            get
            {
                return Item.image1;
            }
            set
            {
                if (Item.image1 != value)
                {
                    Item.image1 = value;
                    OnPropertyChanged(nameof(Image));
                }
            }
        }

        public String Name
        {
            get
            {
                return Item.name;
            }
            set
            {
                if (Item.name != value)
                {
                    Item.name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }

        public String ShortDescription
        {
            get
            {
                return Item.shortdescr;
            }
            set
            {
                if (Item.shortdescr != value)
                {
                    Item.shortdescr = value;
                    OnPropertyChanged(nameof(ShortDescription));
                }
            }
        }

        public String LongDescription
        {
            get
            {
                return Item.longdescr;
            }
            set
            {
                if (Item.longdescr != value)
                {
                    Item.longdescr = value;
                    OnPropertyChanged(nameof(LongDescription));
                }
            }
        }

        protected void OnPropertyChanged(string propertyName)
        {
            if (ReferenceEquals(PropertyChanged, null))
            {
                PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
