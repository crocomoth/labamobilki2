﻿using labamobilki2.Model;
using labamobilki2.Parsers;
using labamobilki2.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace labamobilki2
{
    public partial class MainPage : ContentPage
    {
        public ItemsTableViewModel ViewModel { get; private set; }

        public MainPage()
        {
            InitializeComponent();

            var jsonParser = new JSONParser();

            var repository = new Items();
            repository.items = new List<Item>()
            {
                new Item()
                {
                    image1 = "infantry",
                    image2 = "infantrymain",
                    name = "infantry",
                    shortdescr = "main power of any war",
                    longdescr = "Infantry is the branch of an army that engages in military combat on foot, distinguished from cavalry, artillery, and tank forces. Also known as foot soldiers, infantry traditionally relies on moving by foot between combats as well, but may also use mounts, military vehicles, or other transport. Infantry make up a large portion of all armed forces in most nations, and typically bear the largest brunt in warfare, as measured by casualties, deprivation, or physical and psychological stress./nThe first military forces in history were infantry. In antiquity, infantry were armed with an early melee weapon such as a spear, axe or sword, or an early ranged weapon like a javelin, sling, or bow, with a few infantrymen having both a melee and a ranged weapon. With the development of gunpowder, infantry began converting to primarily firearms. By the time of Napoleonic warfare, infantry, cavalry, and artillery formed a basic triad of ground forces, though infantry usually remained the most numerous. With armoured warfare, armoured fighting vehicles have replaced the horses of cavalry, and airpower has added a new dimension to ground combat, but infantry remains pivotal to all modern combined arms operations./nInfantry have much greater local situational awareness than other military forces, due to their inherent intimate contact with the battlefield (boots on the ground); this is vital for taking or holding ground (any military objectives), securing battlefield victories, maintaining military area control and security both at and behind the front lines, for capturing ordnance or materiel, taking prisoners, and military occupation. Infantry can more easily recognise, adapt and respond to local conditions, weather, and changing enemy weapons or tactics. They can operate in a wide range of terrain inaccessible to military vehicles, and can operate with a lower logistical burden. Infantry are most easily deliverable forces to ground combat areas, by simple and reliable marching, or by trucks, sea or air transport; they can also be inserted directly into combat by amphibious landing, or for air assault by parachute or helicopter (airmobile or airborne infantry). They can be augmented with a variety of crew-served weapons and armored personnel carriers.",
                    link = "https://en.wikipedia.org/wiki/Infantry"
                }
            };
            ViewModel = new ItemsTableViewModel(repository);

            this.BindingContext = ViewModel;
        }

        private async void ItemListView_OnItemTapped(object sender, ItemTappedEventArgs e)
        {
            VMMain selectedItem = e.Item as VMMain;
            VMDescription description = selectedItem.GenerateDescription();
            if (selectedItem != null)
            {
                await Navigation.PushAsync(new DescriptionContent(description));
            }

            ItemListView.SelectedItem = null;
        }
    }
}
