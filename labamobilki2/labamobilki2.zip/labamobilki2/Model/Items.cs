﻿using System;
using System.Collections.Generic;
using System.Text;

namespace labamobilki2.Model
{
    public class Items
    {
        public List<Item> items;
    }
}
