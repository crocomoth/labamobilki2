﻿using System;
using System.Collections.Generic;
using System.Text;

namespace labamobilki2.Model
{
    public class Item
    {
        public string name;
        public string shortdescr;
        public string longdescr;
        public string image1; // small image
        public string image2; // big image
        public string link;
    }
}
